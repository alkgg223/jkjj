package com.turkeymod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.turkeymod.TurkeyMod;
import com.turkeymod.entity.TurkeyEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class TurkeyRenderer extends MobRenderer<TurkeyEntity, TurkeyModel> {
    private static final ResourceLocation MALE =
            ResourceLocation.fromNamespaceAndPath(TurkeyMod.MODID, "textures/entity/turkey_male.png");
    private static final ResourceLocation FEMALE =
            ResourceLocation.fromNamespaceAndPath(TurkeyMod.MODID, "textures/entity/turkey_female.png");

    public TurkeyRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new TurkeyModel(ctx.bakeLayer(TurkeyModel.LAYER)), 0.45F);
    }

    @Override
    public ResourceLocation getTextureLocation(TurkeyEntity entity) {
        return entity.isMale() ? MALE : FEMALE;
    }

    @Override
    protected void scale(TurkeyEntity entity, PoseStack pose, float partialTick) {
        float s = entity.isMale() ? 1.0F : 0.88F;
        if (entity.isBaby()) s *= 0.5F;
        pose.scale(s, s, s);
    }
}
