package com.turkeymod.registry;

import com.turkeymod.TurkeyMod;
import com.turkeymod.item.TurkeyEggItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(Registries.ITEM, TurkeyMod.MODID);

    public static final DeferredHolder<Item, DeferredSpawnEggItem> TURKEY_SPAWN_EGG =
            ITEMS.register("turkey_spawn_egg", () ->
                    new DeferredSpawnEggItem(ModEntities.TURKEY, 0x6B4423, 0xC9302C, new Item.Properties()));

    public static final DeferredHolder<Item, BlockItem> TURKEY_NEST =
            ITEMS.register("turkey_nest", () ->
                    new BlockItem(ModBlocks.TURKEY_NEST.get(), new Item.Properties()));

    public static final DeferredHolder<Item, TurkeyEggItem> TURKEY_EGG =
            ITEMS.register("turkey_egg", () -> new TurkeyEggItem(new Item.Properties().stacksTo(16)));

    public static final DeferredHolder<Item, Item> TURKEY_DROPPINGS =
            ITEMS.register("turkey_droppings", () -> new Item(new Item.Properties()));

    public static final DeferredHolder<Item, Item> RAW_TURKEY =
            ITEMS.register("raw_turkey", () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(2).saturationModifier(0.3F)
                            .effect(new MobEffectInstance(MobEffects.HUNGER, 600, 0), 0.3F).build())));

    public static final DeferredHolder<Item, Item> COOKED_TURKEY =
            ITEMS.register("cooked_turkey", () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationModifier(0.8F).build())));

    public static final DeferredHolder<Item, Item> TURKEY_SKIN =
            ITEMS.register("turkey_skin", () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(1).saturationModifier(0.1F)
                            .effect(new MobEffectInstance(MobEffects.HUNGER, 400, 0), 0.5F).build())));

    public static final DeferredHolder<Item, Item> TURKEY_GIBLETS =
            ITEMS.register("turkey_giblets", () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(2).saturationModifier(0.1F)
                            .effect(new MobEffectInstance(MobEffects.HUNGER, 900, 0), 0.6F).build())));
}
